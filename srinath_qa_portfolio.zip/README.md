# Srinath Dasarathakumar — QA/SDET Portfolio

## Files
- `index.html`: responsive portfolio website. No build tools required.

## Preview locally
Double-click `index.html` to open it in a browser.

## Publish with GitHub Pages
1. Sign in to https://github.com/
2. Create a new **public** repository named `srinathd0812.github.io` (if available).
3. Upload `index.html` to the repository root using **Add file → Upload files**.
4. Commit the upload.
5. Open **Settings → Pages** and select **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save if not already enabled.
6. Wait a few minutes, then open `https://srinathd0812.github.io/`.

If that repository name is unavailable, use any repository name and enable Pages in Settings; the URL will be `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Before sharing
- Check that employment dates and experience claims match documents you can substantiate.
- Add your real GitHub profile and resume PDF link if you want them on the page.
- The email and phone links are included from the resume information supplied.
